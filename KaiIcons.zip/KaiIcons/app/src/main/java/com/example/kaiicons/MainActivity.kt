package com.example.kaiicons

import android.Manifest
import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class ChipView(ctx: Context, private val s: Scheme) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        p.style = Paint.Style.FILL; p.color = s.bg
        c.drawRoundRect(0f, 0f, w, w, w * 0.3f, w * 0.3f, p)
        p.style = Paint.Style.STROKE; p.color = s.logo; p.strokeWidth = w * 0.12f
        c.drawCircle(w / 2, w / 2, w * 0.2f, p)
    }
}

class MainActivity : AppCompatActivity() {

    private val cBg = 0xFF1B1513.toInt()
    private val cCard = 0xFF2A2220.toInt()
    private val cPill = 0xFF3B302D.toInt()
    private val cPeach = 0xFFFFB4A2.toInt()
    private val cTxt = 0xFFF1E4DE.toInt()
    private val cSub = 0xFF9C8E88.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var wall: Bitmap? = null
    private var schemes = mutableListOf<Scheme>()
    private var sel = 0
    private lateinit var current: Scheme
    private var apps: List<AppIcon> = emptyList()
    private var forced = false
    private var noCircle = false

    private lateinit var wallImg: ImageView
    private lateinit var wallLabel: TextView
    private lateinit var chips: LinearLayout
    private lateinit var info: TextView
    private lateinit var prevWall: ImageView
    private lateinit var prevRow: LinearLayout
    private lateinit var forceDesc: TextView
    private lateinit var forceRow: LinearLayout
    private lateinit var forceCap: TextView
    private lateinit var createBtn: TextView

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) decode(uri)?.let { setWall(it, "Своя картинка") }
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        loadSystemWallpaper()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    private fun rounded(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke > 0) setStroke(stroke, strokeColor)
    }

    private fun clipRounded(v: View, r: Int) {
        v.background = rounded(cPill, r)
        v.outlineProvider = ViewOutlineProvider.BACKGROUND
        v.clipToOutline = true
    }

    private fun text(t: String, sp: Float, bold: Boolean = false, color: Int = cTxt) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(cTxt); gravity = Gravity.CENTER
        background = rounded(cPill, 14)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick() }
    }

    private fun card(title: String? = null) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cCard, 20)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
        if (title != null) addView(text(title, 15f, true))
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }
        root.addView(text("✦ Icon manager", 22f, true))
        root.addView(text("иконки для Xiaomi из цветов твоих обоев", 12f, false, cSub))

        // --- Обои ---
        val c1 = card("Обои")
        val fr = FrameLayout(this)
        wallImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; clipRounded(this, 14) }
        wallLabel = text("", 11f).apply {
            background = rounded(0x99000000.toInt(), 10)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        fr.addView(wallImg, FrameLayout.LayoutParams(MATCH, dp(150)))
        fr.addView(wallLabel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
            .apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        c1.addView(fr, lp(10))
        val row1 = LinearLayout(this)
        row1.addView(pill("📱 Обои телефона") { onSystemWallpaper() },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(8) })
        row1.addView(pill("🖼 Галерея / файл") { picker.launch("image/*") }, LinearLayout.LayoutParams(0, WRAP, 1f))
        c1.addView(row1, lp(10))
        root.addView(c1)

        // --- Цвета ---
        val c2 = card()
        val h2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        h2.addView(text("Цвета", 15f, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        h2.addView(pill("⇄") { swap() }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) })
        h2.addView(pill("✎ Своё") { customColor() })
        c2.addView(h2)
        chips = LinearLayout(this)
        c2.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }, lp(12))
        info = text("", 11f, false, cSub)
        c2.addView(info, lp(8))
        root.addView(c2)

        // --- Превью ---
        val c3 = card("Так будет выглядеть")
        val pf = FrameLayout(this)
        prevWall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; clipRounded(this, 14) }
        prevRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pf.addView(prevWall, FrameLayout.LayoutParams(MATCH, dp(110)))
        pf.addView(prevRow, FrameLayout.LayoutParams(MATCH, dp(110)))
        c3.addView(pf, lp(10))
        root.addView(c3)

        // --- Принудительный перекрас ---
        val c4 = card()
        val h4 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text("Принудительный перекрас приложений", 15f, true))
        forceDesc = text("", 11f, false, cSub)
        col.addView(forceDesc, lp(4))
        h4.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(10) })
        h4.addView(Switch(this).apply {
            setOnCheckedChangeListener { _, v -> forced = v; refreshPreview() }
        })
        c4.addView(h4)
        c4.addView(Switch(this).apply {
            text = "Без кружков: чистый логотип на плитке"
            textSize = 13f
            setTextColor(cTxt)
            setOnCheckedChangeListener { _, v -> noCircle = v; refreshPreview() }
        }, lp(10))
        forceCap = text("Примерно так система перекрасит остальные приложения", 11f, false, cSub)
        c4.addView(forceCap, lp(12))
        forceRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        c4.addView(forceRow, lp(6))
        c4.addView(text("Чёткость силуэта", 12f, false, cSub), lp(12))
        c4.addView(SeekBar(this).apply {
            max = 100; progress = 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { Recolor.sharp = p / 100f; refreshPreview() }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        c4.addView(text("Толщина значка", 12f, false, cSub), lp(8))
        c4.addView(SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { Recolor.bold = p / 100f; refreshPreview() }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        slider(c4, "Чистка мусора и шума", 40) { Recolor.cleanup = it }
        slider(c4, "Размер значка", 60) { Recolor.glyphSize = 0.45f + 0.45f * it }
        slider(c4, "Объём (градиент и блик)", 0) { Recolor.volume = it }
        slider(c4, "Плотность плитки (слева — прозрачнее)", 100) { Recolor.tileAlpha = 0.4f + 0.6f * it }
        root.addView(c4)

        // --- Создать ---
        createBtn = TextView(this).apply {
            text = "✦ Создать иконки"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(0xFF3A1F18.toInt()); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFFFFB4A2.toInt(), 0xFFD9908A.toInt())).apply { cornerRadius = dp(24).toFloat() }
            setPadding(0, dp(16), 0, dp(16))
            setOnClickListener { create() }
        }
        root.addView(createBtn, lp(16))

        setContentView(ScrollView(this).apply { setBackgroundColor(cBg); addView(root) })

        schemes = Recolor.fromSeeds(listOf(0xFFB5835A.toInt())).toMutableList()
        current = schemes[0]
        wallLabel.text = "Выбери обои"
        rebuildChips(); refreshPreview()
        thread {
            val a = Recolor.loadApps(this)
            runOnUiThread { apps = a; refreshPreview() }
        }
    }

    // ---------- Обои ----------
    private fun onSystemWallpaper() {
        if (Build.VERSION.SDK_INT < 33 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE) else loadSystemWallpaper()
    }

    private fun loadSystemWallpaper() {
        try {
            val d = WallpaperManager.getInstance(this).drawable ?: throw IllegalStateException()
            val w = max(d.intrinsicWidth, 1); val h = max(d.intrinsicHeight, 1)
            val k = min(1f, 1080f / max(w, h))
            val b = Bitmap.createBitmap((w * k).toInt().coerceAtLeast(1), (h * k).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, b.width, b.height); d.draw(Canvas(b))
            setWall(b, "Обои телефона")
        } catch (e: Exception) {
            toast("Нет доступа к обоям — выбери картинку из галереи")
        }
    }

    private fun decode(uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun setWall(b: Bitmap, label: String) {
        wall = b
        wallImg.setImageBitmap(b); wallLabel.text = label
        schemes = Recolor.schemes(b).toMutableList()
        sel = 0; current = schemes[0]
        rebuildChips(); refreshPreview()
    }

    // ---------- Цвета ----------
    private fun rebuildChips() {
        chips.removeAllViews()
        schemes.forEachIndexed { i, s ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(4))
                if (i == sel) background = rounded(0, 16, dp(2), cPeach)
                setOnClickListener { sel = i; current = schemes[i]; rebuildChips(); refreshPreview() }
            }
            col.addView(ChipView(this, s), LinearLayout.LayoutParams(dp(56), dp(56)))
            col.addView(text(s.label, 11f, false, cSub).apply { gravity = Gravity.CENTER })
            chips.addView(col, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(6) })
        }
    }

    private fun swap() {
        val nb = current.logo
        val label = if (current.label == "Яркий" || current.label == "Своё") current.label
            else if (androidx.core.graphics.ColorUtils.calculateLuminance(nb) > 0.4) "Светлый" else "Тёмный"
        current = current.copy(label = label, bg = nb, logo = current.bg)
        if (sel in schemes.indices) schemes[sel] = current
        rebuildChips(); refreshPreview()
    }

    private fun customColor() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val e1 = EditText(this).apply { hint = "Фон, напр. #322D28"; setText(hex(current.bg)) }
        val e2 = EditText(this).apply { hint = "Логотип, напр. #D5CCC3"; setText(hex(current.logo)) }
        l.addView(e1); l.addView(e2)
        AlertDialog.Builder(this).setTitle("Своё").setView(l)
            .setPositiveButton("OK") { _, _ ->
                try {
                    current = Scheme("Своё", Color.parseColor(e1.text.toString().trim()), Color.parseColor(e2.text.toString().trim()))
                    schemes.add(0, current); sel = 0
                    rebuildChips(); refreshPreview()
                } catch (e: Exception) { toast("Неверный цвет, нужен формат #RRGGBB") }
            }.setNegativeButton("Отмена", null).show()
    }

    // ---------- Превью ----------
    private fun slider(parent: LinearLayout, title: String, start: Int, onChange: (Float) -> Unit) {
        parent.addView(text(title, 12f, false, cSub), lp(8))
        parent.addView(SeekBar(this).apply {
            max = 100; progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { onChange(p / 100f); refreshPreview() }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
    }

    private fun refreshPreview() {
        if (wall != null) { prevWall.setImageBitmap(wall) } else prevWall.setImageDrawable(null)
        prevRow.removeAllViews()
        forceRow.removeAllViews()
        forceCap.visibility = if (forced) View.VISIBLE else View.GONE
        forceCap.text = if (noCircle) "Так будут выглядеть остальные приложения: чистый логотип"
            else "Примерно так система перекрасит остальные (тусклые иконки усилятся автоматически)"
        // 1) обычные: приложения с монохромной иконкой (тема Android 13+)
        val normal = apps.filter { it.hasMono }.take(4).ifEmpty { apps.take(4) }
        normal.forEach { a ->
            prevRow.addView(ImageView(this).apply { setImageBitmap(Recolor.render(a, current, 160)) },
                LinearLayout.LayoutParams(dp(68), dp(68)).apply { marginStart = dp(6); marginEnd = dp(6) })
        }
        // 2) принудительные: все остальные приложения, перекрашенные в твои цвета
        if (forced) {
            apps.filter { !it.hasMono }.take(5).forEach { a ->
                forceRow.addView(ImageView(this).apply { setImageBitmap(Recolor.forcedIcon(a, current, 160, noCircle)) },
                    LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(4); marginEnd = dp(4) })
            }
        }
        info.text = String.format(Locale("ru"), "фон %s · логотип %s · контраст %.1f:1",
            hex(current.bg), hex(current.logo), current.contrast)
        val monoCount = apps.count { it.hasMono }
        forceDesc.text = "Остальные приложения (${apps.size - monoCount}) перекрасит сама система Xiaomi, как в оригинальных темах: " +
            "иконка станет двухцветной в твоих цветах и всегда без артефактов." +
            if (forced) "" else "\nСейчас перекрасятся только приложения с монохромной иконкой: $monoCount."
    }

    // ---------- Создание .mtz ----------
    private fun create() {
        val s0 = current
        val mono = apps.filter { it.hasMono }.map { it to false }
        val extra = if (forced) apps.filter { !it.hasMono && (noCircle || Recolor.isDim(it, s0)) }.map { it to true } else emptyList()
        val items = mono + extra
        if (!forced && items.isEmpty()) { toast("Нет приложений с монохромной иконкой. Включи «Принудительный перекрас»."); return }
        createBtn.isEnabled = false; createBtn.text = "Создаю…"
        val s = current
        thread {
            val msg = try {
                val data = Recolor.buildMtz(items, s, forced)
                val name = "IconManager_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, "$name.mtz")
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/IconManager")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                    ?: throw IllegalStateException("не удалось создать файл")
                contentResolver.openOutputStream(uri)?.use { it.write(data) }
                "Готово: Download/IconManager/$name.mtz (${items.size} иконок" + (if (forced) " + перекрас остальных системой)" else ")")
            } catch (e: Exception) { "Ошибка: ${e.message}" }
            runOnUiThread { createBtn.isEnabled = true; createBtn.text = "✦ Создать иконки"; toast(msg) }
        }
    }
}
