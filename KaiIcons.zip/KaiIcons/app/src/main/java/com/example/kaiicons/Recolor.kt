package com.example.kaiicons

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

data class Scheme(val label: String, val bg: Int, val logo: Int) {
    val contrast: Double get() = ColorUtils.calculateContrast(logo, bg)
}

class AppIcon(
    val pkg: String,
    val activity: String,
    val label: String,
    val drawable: Drawable,
    val hasMono: Boolean
)

object Recolor {

    /** Чёткость силуэта 0..1 */
    var sharp = 0.8f

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }

    // ---------- Список приложений ----------
    fun loadApps(ctx: Context): List<AppIcon> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            try {
                val d = ri.loadIcon(pm)
                val mono = Build.VERSION.SDK_INT >= 33 && d is AdaptiveIconDrawable && hasMonochrome(d)
                AppIcon(ri.activityInfo.packageName, ri.activityInfo.name, ri.loadLabel(pm).toString(), d, mono)
            } catch (e: Exception) { null }
        }.distinctBy { it.pkg }.filter { it.pkg != ctx.packageName }.sortedBy { it.label.lowercase() }
    }

    @SuppressLint("NewApi")
    private fun hasMonochrome(d: AdaptiveIconDrawable) = d.monochrome != null

    // ---------- Палитра из обоев ----------
    fun schemes(wall: Bitmap): List<Scheme> {
        val h = (96f * wall.height / wall.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(wall, 96, h, true)
        val p = Palette.from(small).maximumColorCount(24).generate()
        val seeds = listOfNotNull(
            p.vibrantSwatch?.rgb, p.dominantSwatch?.rgb, p.mutedSwatch?.rgb,
            p.darkVibrantSwatch?.rgb, p.darkMutedSwatch?.rgb
        ).distinct()
        return fromSeeds(if (seeds.isEmpty()) listOf(0xFFB5835A.toInt()) else seeds)
    }

    fun fromSeeds(seeds: List<Int>): List<Scheme> {
        val out = mutableListOf<Scheme>()
        seeds.forEachIndexed { i, s ->
            out += dark(s)
            if (i < 2) out += light(s)
            if (i == 1 || seeds.size == 1) out += vivid(s)
        }
        return out
    }

    private fun hsl(c: Int) = FloatArray(3).also { ColorUtils.colorToHSL(c, it) }
    private fun mk(h: Float, s: Float, l: Float) =
        ColorUtils.HSLToColor(floatArrayOf(h, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f)))

    private fun dark(seed: Int): Scheme {
        val h = hsl(seed)
        return ensure(Scheme("Тёмный", mk(h[0], min(h[1], 0.45f), 0.18f), mk(h[0], min(h[1], 0.4f), 0.82f)))
    }

    private fun light(seed: Int): Scheme {
        val h = hsl(seed)
        return ensure(Scheme("Светлый", mk(h[0], min(h[1], 0.4f), 0.92f), mk(h[0], h[1].coerceAtLeast(0.35f), 0.4f)))
    }

    private fun vivid(seed: Int): Scheme {
        val h = hsl(seed)
        return ensure(Scheme("Яркий", mk(h[0], h[1].coerceAtLeast(0.55f), 0.40f), mk(h[0], 0.6f, 0.95f)))
    }

    private fun ensure(s: Scheme): Scheme {
        var logo = s.logo
        val lightBg = ColorUtils.calculateLuminance(s.bg) > 0.4
        var tries = 0
        while (ColorUtils.calculateContrast(logo, s.bg) < 4.5 && tries++ < 20) {
            val h = hsl(logo)
            h[2] = (h[2] + if (lightBg) -0.05f else 0.05f).coerceIn(0f, 1f)
            logo = ColorUtils.HSLToColor(h)
        }
        return s.copy(logo = logo)
    }

    // ---------- Перекраска иконки ----------
    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val k = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return k * k * (3 - 2 * k)
    }

    fun render(app: AppIcon, s: Scheme, size: Int): Bitmap {
        val n = size * 2 // рисуем в 2x и уменьшаем: края получаются гладкими
        val d = app.drawable
        val src = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(src)
        val big = Rect(-n / 4, -n / 4, n + n / 4, n + n / 4)
        var mono = false
        if (app.hasMono) {
            mono = true
            drawMono(d as AdaptiveIconDrawable, c, big)
        } else if (d is AdaptiveIconDrawable) {
            d.background?.let { it.setBounds(big); it.draw(c) }
            d.foreground?.let { it.setBounds(big); it.draw(c) }
        } else {
            d.setBounds(0, 0, n, n); d.draw(c)
        }

        val px = IntArray(n * n)
        src.getPixels(px, 0, n, 0, 0, n, n)
        val ref: Int? = if (mono) null else estimateBg(px, n)
        val out = IntArray(px.size)
        for (i in px.indices) {
            val p = px[i]
            val a = (p ushr 24) / 255f
            val t = if (ref == null) a else {
                val dr = Color.red(p) - Color.red(ref)
                val dg = Color.green(p) - Color.green(ref)
                val db = Color.blue(p) - Color.blue(ref)
                val dist = sqrt((dr * dr + dg * dg + db * db).toFloat()) / 441.67f
                // плоские два цвета: убираем градиенты и мелкий шум оригинала
                smooth(0.2f, 0.42f, dist) * a
            }
            out[i] = ColorUtils.blendARGB(s.bg, s.logo, t)
        }
        val tmp = Bitmap.createBitmap(out, n, n, Bitmap.Config.ARGB_8888)
        val res = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(tmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        Canvas(res).drawPath(squircle(n.toFloat()), paint)
        return Bitmap.createScaledBitmap(res, size, size, true)
    }

    @SuppressLint("NewApi")
    private fun drawMono(d: AdaptiveIconDrawable, c: Canvas, b: Rect) {
        d.monochrome?.let { it.setBounds(b); it.draw(c) }
    }

    /** Цвет фона иконки: по краю, а если края прозрачные — самый частый цвет. */
    private fun estimateBg(px: IntArray, n: Int): Int? {
        val ring = 3
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        var total = 0
        for (y in 0 until n) for (x in 0 until n) {
            if (x >= ring && y >= ring && x < n - ring && y < n - ring) continue
            total++
            val p = px[y * n + x]
            if ((p ushr 24) > 200) { rs.add(Color.red(p)); gs.add(Color.green(p)); bs.add(Color.blue(p)) }
        }
        if (rs.size > total * 0.6) {
            rs.sort(); gs.sort(); bs.sort()
            return Color.rgb(rs[rs.size / 2], gs[gs.size / 2], bs[bs.size / 2])
        }
        val hist = HashMap<Int, Int>()
        var opaque = 0
        for (p in px) if ((p ushr 24) > 200) {
            opaque++
            val k = ((Color.red(p) shr 4) shl 8) or ((Color.green(p) shr 4) shl 4) or (Color.blue(p) shr 4)
            hist[k] = (hist[k] ?: 0) + 1
        }
        val top = hist.maxByOrNull { it.value } ?: return null
        if (opaque == 0 || top.value < opaque * 0.4) return null
        val k = top.key
        return Color.rgb(((k shr 8) and 15) * 17, ((k shr 4) and 15) * 17, (k and 15) * 17)
    }

    private fun squircle(size: Float, n: Double = 5.0): Path {
        val p = Path()
        val a = size / 2.0
        val steps = 180
        for (i in 0..steps) {
            val t = 2 * Math.PI * i / steps
            val ct = cos(t); val st = sin(t)
            val x = a + a * sign(ct) * abs(ct).pow(2.0 / n)
            val y = a + a * sign(st) * abs(st).pow(2.0 / n)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
        return p
    }

    // ---------- Сборка .mtz ----------
    fun buildMtz(apps: List<AppIcon>, s: Scheme, size: Int = 192): ByteArray {
        val seen = HashSet<String>()
        val icons = ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                for (a in apps) {
                    val png = ByteArrayOutputStream().also {
                        render(a, s, size).compress(Bitmap.CompressFormat.PNG, 100, it)
                    }.toByteArray()
                    for (name in listOf(a.pkg, a.activity)) if (seen.add(name)) {
                        z.putNextEntry(ZipEntry("res/drawable-xxhdpi/$name.png"))
                        z.write(png); z.closeEntry()
                    }
                }
            }
        }.toByteArray()

        val prev = Bitmap.createBitmap(720, 360, Bitmap.Config.ARGB_8888)
        Canvas(prev).apply {
            drawColor(ColorUtils.blendARGB(s.bg, Color.BLACK, 0.35f))
            apps.take(4).forEachIndexed { i, a ->
                drawBitmap(render(a, s, 128), 90f + i * 150f, 116f, null)
            }
        }
        val prevJpg = ByteArrayOutputStream().also { prev.compress(Bitmap.CompressFormat.JPEG, 90, it) }.toByteArray()

        val desc = """<?xml version="1.0" encoding="utf-8"?>
<MIUI-Theme>
    <title>Kai Icons</title>
    <designer>Kai Icons</designer>
    <author>Kai Icons</author>
    <version>1.0</version>
    <uiVersion>1</uiVersion>
    <description>Icons generated from wallpaper colors</description>
</MIUI-Theme>
"""
        return ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                z.putNextEntry(ZipEntry("description.xml")); z.write(desc.toByteArray()); z.closeEntry()
                z.putNextEntry(ZipEntry("icons")); z.write(icons); z.closeEntry()
                z.putNextEntry(ZipEntry("preview/preview_icons_0.jpg")); z.write(prevJpg); z.closeEntry()
            }
        }.toByteArray()
    }
}
