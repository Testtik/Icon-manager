package com.example.kaiicons

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

data class Scheme(val label: String, val bg: Int, val logo: Int) {
    val contrast: Double get() = ColorUtils.calculateContrast(logo, bg)
}

class AppIcon(
    val pkg: String,
    val activity: String,
    val label: String,
    val drawable: Drawable,
    val hasMono: Boolean
)

object Recolor {

    /** Чёткость силуэта 0..1 */
    var sharp = 0.8f

    /** Толщина значка 0..1 */
    var bold = 0.5f

    /** Размер значка внутри плитки 0.45..0.9 (у оригинальных тем ~0.73) */
    var glyphSize = 0.72f

    /** Объём: градиент и блик, 0 = плоская плитка */
    var volume = 0f

    /** Непрозрачность плитки 0.4..1 */
    var tileAlpha = 1f

    /** Чистка мусора и шума 0..1 */
    var cleanup = 0.4f

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }

    // ---------- Список приложений ----------
    fun loadApps(ctx: Context): List<AppIcon> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            try {
                val d = rawIcon(pm, ri) ?: ri.loadIcon(pm)
                val mono = Build.VERSION.SDK_INT >= 33 && d is AdaptiveIconDrawable && hasMonochrome(d)
                AppIcon(ri.activityInfo.packageName, ri.activityInfo.name, ri.loadLabel(pm).toString(), d, mono)
            } catch (e: Exception) { null }
        }.distinctBy { it.pkg }.filter { it.pkg != ctx.packageName }.sortedBy { it.label.lowercase() }
    }

    /** Иконка из ресурсов самого приложения, без блика и маски, которые добавляет оболочка Xiaomi. */
    private fun rawIcon(pm: PackageManager, ri: ResolveInfo): Drawable? = try {
        val ai = ri.activityInfo
        val id = ai.iconResource
        if (id == 0) null else {
            val res = pm.getResourcesForApplication(ai.applicationInfo)
            ResourcesCompat.getDrawableForDensity(res, id, 640, null)
        }
    } catch (e: Exception) { null }

    @SuppressLint("NewApi")
    private fun hasMonochrome(d: AdaptiveIconDrawable) = d.monochrome != null

    // ---------- Палитра из обоев ----------
    fun schemes(wall: Bitmap): List<Scheme> {
        val h = (96f * wall.height / wall.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(wall, 96, h, true)
        val p = Palette.from(small).maximumColorCount(24).generate()
        val seeds = listOfNotNull(
            p.vibrantSwatch?.rgb, p.dominantSwatch?.rgb, p.mutedSwatch?.rgb,
            p.darkVibrantSwatch?.rgb, p.darkMutedSwatch?.rgb
        ).distinct()
        return fromSeeds(if (seeds.isEmpty()) listOf(0xFFB5835A.toInt()) else seeds)
    }

    fun fromSeeds(seeds: List<Int>): List<Scheme> {
        val out = mutableListOf<Scheme>()
        seeds.forEachIndexed { i, s ->
            out += dark(s)
            if (i < 2) out += light(s)
            if (i == 1 || seeds.size == 1) out += vivid(s)
        }
        return out
    }

    private fun hsl(c: Int) = FloatArray(3).also { ColorUtils.colorToHSL(c, it) }
    private fun mk(h: Float, s: Float, l: Float) =
        ColorUtils.HSLToColor(floatArrayOf(h, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f)))

    private fun dark(seed: Int): Scheme {
        val h = hsl(seed)
        return ensure(Scheme("Тёмный", mk(h[0], min(h[1], 0.45f), 0.18f), mk(h[0], min(h[1], 0.4f), 0.82f)))
    }

    private fun light(seed: Int): Scheme {
        val h = hsl(seed)
        return ensure(Scheme("Светлый", mk(h[0], min(h[1], 0.4f), 0.92f), mk(h[0], h[1].coerceAtLeast(0.35f), 0.4f)))
    }

    private fun vivid(seed: Int): Scheme {
        val h = hsl(seed)
        return ensure(Scheme("Яркий", mk(h[0], h[1].coerceAtLeast(0.55f), 0.40f), mk(h[0], 0.6f, 0.95f)))
    }

    private fun ensure(s: Scheme): Scheme {
        var logo = s.logo
        val lightBg = ColorUtils.calculateLuminance(s.bg) > 0.4
        var tries = 0
        while (ColorUtils.calculateContrast(logo, s.bg) < 4.5 && tries++ < 20) {
            val h = hsl(logo)
            h[2] = (h[2] + if (lightBg) -0.05f else 0.05f).coerceIn(0f, 1f)
            logo = ColorUtils.HSLToColor(h)
        }
        return s.copy(logo = logo)
    }

    // ---------- Перекраска иконки ----------
    fun render(app: AppIcon, s: Scheme, size: Int): Bitmap {
        val n = size * 2 // рисуем в 2x и уменьшаем: края получаются гладкими
        val d = app.drawable
        d.setFilterBitmap(true)
        val src = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(src)
        val big = Rect(0, 0, n, n) // слой иконки целиком, без обрезания краёв; дальше значок масштабируется сам
        var mono = false
        if (app.hasMono) {
            mono = true
            drawMono(d as AdaptiveIconDrawable, c, big)
        } else if (d is AdaptiveIconDrawable) {
            d.background?.let { it.setFilterBitmap(true); it.setBounds(big); it.draw(c) }
            d.foreground?.let { it.setFilterBitmap(true); it.setBounds(big); it.draw(c) }
        } else {
            d.setBounds(0, 0, n, n); d.draw(c)
        }

        val px = IntArray(n * n)
        src.getPixels(px, 0, n, 0, 0, n, n)
        val ref: Int? = if (mono) null else estimateBg(px, n)

        // «насколько пиксель отличается от фона»
        var score = FloatArray(n * n)
        for (i in px.indices) {
            val p = px[i]
            val a = (p ushr 24) / 255f
            score[i] = if (ref == null) a else {
                val dr = Color.red(p) - Color.red(ref)
                val dg = Color.green(p) - Color.green(ref)
                val db = Color.blue(p) - Color.blue(ref)
                (sqrt((dr * dr + dg * dg + db * db).toFloat()) / 441.67f).coerceAtMost(1f) * a
            }
        }
        // обнуляем тонкий край: убирает светлые «огрызки» по краям у старых иконок
        val edge = (n * 0.025f).toInt()
        for (y in 0 until n) for (x in 0 until n) {
            if (x < edge || y < edge || x >= n - edge || y >= n - edge) score[y * n + x] = 0f
        }
        // чистка: убираем мелкие пятна и «пыль» от сжатия оригинала
        removeSpecks(score, n, ((0.00015f + 0.0010f * cleanup) * n * n).toInt())
        // как в ColorOS: значок по центру и одного размера у всех приложений
        score = fitGlyph(score, n)

        val soft = blur(score, n, maxOf(1, (n / 110f * (0.7f + 0.8f * cleanup)).toInt()))
        val w = 0.42f - 0.38f * sharp // чем выше чёткость, тем резче граница
        val shift = 0.14f * bold // чем толще, тем ниже порог -> значок «разрастается»
        val lo = if (ref == null) 0.5f - shift - 0.15f else 0.3f - shift - w / 2
        val hi = if (ref == null) 0.5f - shift + 0.15f else 0.3f - shift + w / 2

        // мягкий вертикальный градиент у плитки и у значка
        val v = volume
        val bgTop = ColorUtils.blendARGB(s.bg, Color.WHITE, 0.18f * v)
        val bgBot = ColorUtils.blendARGB(s.bg, Color.BLACK, 0.20f * v)
        val fgTop = ColorUtils.blendARGB(s.logo, Color.WHITE, 0.10f * v)
        val fgBot = ColorUtils.blendARGB(s.logo, Color.BLACK, 0.16f * v)
        val out = IntArray(px.size)
        for (y in 0 until n) {
            val k = y / (n - 1f)
            val cb = ColorUtils.blendARGB(bgTop, bgBot, k)
            val cf = ColorUtils.blendARGB(fgTop, fgBot, k)
            for (x in 0 until n) {
                val t = smooth(lo, hi, soft[y * n + x])
                val col = ColorUtils.blendARGB(cb, cf, t)
                // плитка может быть полупрозрачной, значок остаётся непрозрачным
                val al = ((tileAlpha + (1f - tileAlpha) * t) * 255f).toInt().coerceIn(0, 255)
                out[y * n + x] = (al shl 24) or (col and 0xFFFFFF)
            }
        }

        val tmp = Bitmap.createBitmap(out, n, n, Bitmap.Config.ARGB_8888)
        val res = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(res)
        val shape = squircle(n.toFloat(), 5.2) // как у оригинальных тем ColorOS (n≈5.2)
        canvas.drawPath(shape, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(tmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        })
        // лёгкий блик сверху
        canvas.drawPath(shape, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, n * 0.55f, ((0x2C * v).toInt() shl 24) or 0xFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        })
        return Bitmap.createScaledBitmap(res, size, size, true)
    }

    /** Удаляет изолированные пятна меньше minArea пикселей. */
    private fun removeSpecks(score: FloatArray, n: Int, minArea: Int) {
        if (minArea <= 1) return
        val seen = BooleanArray(n * n)
        val queue = IntArray(n * n)
        val th = 0.25f
        for (start in 0 until n * n) {
            if (seen[start] || score[start] <= th) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen[start] = true
            while (head < tail) {
                val i = queue[head++]
                val x = i % n
                val y = i / n
                if (x > 0) { val j = i - 1; if (!seen[j] && score[j] > th) { seen[j] = true; queue[tail++] = j } }
                if (x < n - 1) { val j = i + 1; if (!seen[j] && score[j] > th) { seen[j] = true; queue[tail++] = j } }
                if (y > 0) { val j = i - n; if (!seen[j] && score[j] > th) { seen[j] = true; queue[tail++] = j } }
                if (y < n - 1) { val j = i + n; if (!seen[j] && score[j] > th) { seen[j] = true; queue[tail++] = j } }
            }
            if (tail < minArea) {
                for (q in 0 until tail) {
                    val i = queue[q]
                    val x = i % n
                    val y = i / n
                    for (dy in -2..2) for (dx in -2..2) {
                        val xx = x + dx
                        val yy = y + dy
                        if (xx in 0 until n && yy in 0 until n) {
                            val k = yy * n + xx
                            if (k == i || score[k] <= th) score[k] = 0f
                        }
                    }
                    score[i] = 0f
                }
            }
        }
    }

    /** Центрирует значок и приводит его к одному размеру (glyphSize от плитки). */
    private fun fitGlyph(score: FloatArray, n: Int): FloatArray {
        val cols = IntArray(n)
        val rows = IntArray(n)
        for (y in 0 until n) for (x in 0 until n) if (score[y * n + x] > 0.5f) { cols[x]++; rows[y]++ }
        val th = maxOf(2, n / 100)
        val x0 = cols.indexOfFirst { it >= th }
        val x1 = cols.indexOfLast { it >= th }
        val y0 = rows.indexOfFirst { it >= th }
        val y1 = rows.indexOfLast { it >= th }
        if (x0 < 0 || y0 < 0 || x1 <= x0 || y1 <= y0) return score
        val bw = (x1 - x0 + 1).toFloat()
        val bh = (y1 - y0 + 1).toFloat()
        val k = (glyphSize * n / maxOf(bw, bh)).coerceIn(0.5f, 2.6f)
        val cx = (x0 + x1 + 1) / 2f
        val cy = (y0 + y1 + 1) / 2f
        val out = FloatArray(score.size)
        for (y in 0 until n) for (x in 0 until n) {
            out[y * n + x] = sample(score, n, cx + (x - n / 2f) / k, cy + (y - n / 2f) / k)
        }
        return out
    }

    private fun sample(a: FloatArray, n: Int, x: Float, y: Float): Float {
        if (x < 0f || y < 0f || x > n - 1f || y > n - 1f) return 0f
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = minOf(x0 + 1, n - 1)
        val y1 = minOf(y0 + 1, n - 1)
        val fx = x - x0
        val fy = y - y0
        val top = a[y0 * n + x0] * (1 - fx) + a[y0 * n + x1] * fx
        val bot = a[y1 * n + x0] * (1 - fx) + a[y1 * n + x1] * fx
        return top * (1 - fy) + bot * fy
    }

    private fun blur(a: FloatArray, n: Int, r: Int): FloatArray {
        val tmp = FloatArray(a.size)
        val out = FloatArray(a.size)
        val k = (2 * r + 1).toFloat()
        for (y in 0 until n) {
            var sum = 0f
            for (x in -r..r) sum += a[y * n + x.coerceIn(0, n - 1)]
            for (x in 0 until n) {
                tmp[y * n + x] = sum / k
                sum += a[y * n + (x + r + 1).coerceAtMost(n - 1)] - a[y * n + (x - r).coerceAtLeast(0)]
            }
        }
        for (x in 0 until n) {
            var sum = 0f
            for (y in -r..r) sum += tmp[y.coerceIn(0, n - 1) * n + x]
            for (y in 0 until n) {
                out[y * n + x] = sum / k
                sum += tmp[(y + r + 1).coerceAtMost(n - 1) * n + x] - tmp[(y - r).coerceAtLeast(0) * n + x]
            }
        }
        return out
    }

    @SuppressLint("NewApi")
    private fun drawMono(d: AdaptiveIconDrawable, c: Canvas, b: Rect) {
        d.monochrome?.let { it.setFilterBitmap(true); it.setBounds(b); it.draw(c) }
    }

    /** Цвет фона иконки: по краю видимой части (без прозрачных полей), иначе самый частый цвет. */
    private fun estimateBg(px: IntArray, n: Int): Int? {
        var minX = n; var minY = n; var maxX = -1; var maxY = -1; var opaque = 0
        for (y in 0 until n) for (x in 0 until n) {
            if ((px[y * n + x] ushr 24) > 200) {
                opaque++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (opaque == 0) return null
        val side = min(maxX - minX + 1, maxY - minY + 1)
        val inset = (side * 0.03f).toInt().coerceAtLeast(1)
        val ringW = (side * 0.04f).toInt().coerceAtLeast(2)

        val ring = HashMap<Int, IntArray>()
        var ringTotal = 0
        var ringOpaque = 0
        for (y in minY..maxY) for (x in minX..maxX) {
            val e = min(min(x - minX, maxX - x), min(y - minY, maxY - y))
            if (e < inset || e >= inset + ringW) continue
            ringTotal++
            val p = px[y * n + x]
            if ((p ushr 24) > 200) { ringOpaque++; addBin(ring, p) }
        }
        if (ringTotal > 0 && ringOpaque > ringTotal * 0.5) topBin(ring)?.let { return it }

        val all = HashMap<Int, IntArray>()
        for (p in px) if ((p ushr 24) > 200) addBin(all, p)
        val best = all.values.maxByOrNull { it[0] } ?: return null
        // иконка без своего фона (только значок на прозрачном) -> null; иначе всегда берём самый частый цвет
        if (best[0] >= opaque * 0.25 || opaque > n * n * 0.6) {
            return Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
        }
        return null
    }

    private fun addBin(m: HashMap<Int, IntArray>, p: Int) {
        val k = ((Color.red(p) shr 4) shl 8) or ((Color.green(p) shr 4) shl 4) or (Color.blue(p) shr 4)
        val a = m.getOrPut(k) { IntArray(4) }
        a[0]++; a[1] += Color.red(p); a[2] += Color.green(p); a[3] += Color.blue(p)
    }

    private fun topBin(m: HashMap<Int, IntArray>): Int? {
        val b = m.values.maxByOrNull { it[0] } ?: return null
        return Color.rgb(b[1] / b[0], b[2] / b[0], b[3] / b[0])
    }

    private fun squircle(size: Float, n: Double = 5.0): Path {
        val p = Path()
        val a = size / 2.0
        val steps = 180
        for (i in 0..steps) {
            val t = 2 * Math.PI * i / steps
            val ct = cos(t); val st = sin(t)
            val x = a + a * sign(ct) * abs(ct).pow(2.0 / n)
            val y = a + a * sign(st) * abs(st).pow(2.0 / n)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
        return p
    }

    /** Примерный вид того, как система Xiaomi сама перекрасит иконку (фильтр GrayScale из transform_config.xml). */
    fun renderSystem(app: AppIcon, s: Scheme, size: Int): Bitmap {
        val n = size * 2
        val out = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawPath(squircle(n.toFloat(), 5.2), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = s.bg })
        val inner = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val d = app.drawable
        d.setFilterBitmap(true)
        val m = (n * 6.5f / 90f).toInt()
        d.setBounds(m, m, n - m, n - m)
        d.draw(Canvas(inner))
        val px = IntArray(n * n)
        inner.getPixels(px, 0, n, 0, 0, n, n)
        for (i in px.indices) {
            val p = px[i]
            val a = p ushr 24
            if (a == 0) continue
            val lum = (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)) / 255f
            px[i] = (a shl 24) or (ColorUtils.blendARGB(s.bg, s.logo, lum) and 0xFFFFFF)
        }
        inner.setPixels(px, 0, n, 0, 0, n, n)
        c.drawBitmap(inner, 0f, 0f, null)
        return Bitmap.createScaledBitmap(out, size, size, true)
    }

    private fun hexOf(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    private fun pngOf(b: Bitmap): ByteArray =
        ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()

    private fun tileBitmap(size: Int, color: Int, alpha: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(b).drawPath(squircle(size.toFloat(), 5.2), Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = (alpha shl 24) or (color and 0xFFFFFF)
        })
        return b
    }

    private fun circleBitmap(size: Int, color: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(b).drawCircle(size / 2f, size / 2f, size * 0.389f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
        return b
    }

    /** Как в оригинальных темах: система сама делает двухцветный перекрас всех остальных приложений. */
    private fun transformXml(s: Scheme): String = (
        "<IconTransform>\n<PointsMapping>\n" +
        "<Point fromX=\"0.0\" fromY=\"0.0\" toX=\"6.5\" toY=\"6.5\"/>\n" +
        "<Point fromX=\"0.0\" fromY=\"90.0\" toX=\"6.5\" toY=\"83.5\"/>\n" +
        "<Point fromX=\"90.0\" fromY=\"90.0\" toX=\"83.5\" toY=\"83.5\"/>\n" +
        "<Point fromX=\"90.0\" fromY=\"0.0\" toX=\"83.5\" toY=\"6.5\"/>\n" +
        "</PointsMapping>\n<IconFilters>\n<Filter name=\"GrayScale\">\n" +
        "<Param name=\"BlackColor\" value=\"${hexOf(s.bg)}\"/>\n" +
        "<Param name=\"WhiteColor\" value=\"${hexOf(s.logo)}\"/>\n" +
        "</Filter>\n</IconFilters>\n</IconTransform>").replace("\n", "\r\n")

    // ---------- Сборка .mtz ----------
    fun buildMtz(apps: List<AppIcon>, s: Scheme, systemRecolor: Boolean, size: Int = 192): ByteArray {
        val seen = HashSet<String>()
        val dark = ColorUtils.calculateLuminance(s.bg) < 0.4
        val icons = ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                fun put(name: String, data: ByteArray) {
                    z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry()
                }
                if (systemRecolor) put("transform_config.xml", transformXml(s).toByteArray())
                // служебные файлы, как в оригинальных темах
                val tile = pngOf(tileBitmap(192, s.bg, 255))
                put("res/drawable-xxhdpi/icon_pattern.png", tile)
                put("res/drawable-xxhdpi/icon_mask\$\$\$.png", tile)
                put("res/drawable-xxhdpi/icon_mask.png", pngOf(circleBitmap(235, s.logo)))
                val folder = pngOf(tileBitmap(192, s.logo, if (dark) 64 else 20))
                put("res/drawable-xxhdpi/icon_folder.png", folder)
                put("res/drawable-xxhdpi/icon_folder_light.png", folder)
                val grid = pngOf(tileBitmap(192, s.logo, if (dark) 77 else 24))
                put("res/drawable-xxhdpi/folder_bg_grid_four_reserved.png", grid)
                put("res/drawable-xxhdpi/folder_bg_grid_four_light_reserved.png", grid)
                for (a in apps) {
                    val png = pngOf(render(a, s, size))
                    for (name in listOf(a.pkg, a.activity)) if (seen.add(name)) {
                        put("res/drawable-xxhdpi/$name.png", png)
                    }
                }
            }
        }.toByteArray()

        val prev = Bitmap.createBitmap(720, 360, Bitmap.Config.ARGB_8888)
        Canvas(prev).apply {
            drawColor(ColorUtils.blendARGB(s.bg, Color.BLACK, 0.35f))
            apps.take(4).forEachIndexed { i, a ->
                drawBitmap(render(a, s, 128), 90f + i * 150f, 116f, null)
            }
        }
        val prevJpg = ByteArrayOutputStream().also { prev.compress(Bitmap.CompressFormat.JPEG, 90, it) }.toByteArray()

        val desc = """<?xml version="1.0" encoding="utf-8" standalone="no"?>
<theme>
<version><![CDATA[1.0]]></version>
<uiVersion>17</uiVersion>
<author><![CDATA[Kai Icons]]></author>
<designer><![CDATA[Kai Icons]]></designer>
<title><![CDATA[Kai Icons]]></title>
<description><![CDATA[Icons generated from wallpaper colors]]></description>
<authors>
<author locale="en_US"><![CDATA[Kai Icons]]></author>
<author locale="zh_CN"><![CDATA[Kai Icons]]></author>
</authors>
<designers>
<designer locale="en_US"><![CDATA[Kai Icons]]></designer>
<designer locale="zh_CN"><![CDATA[Kai Icons]]></designer>
</designers>
<titles>
<title locale="en_US"><![CDATA[Kai Icons]]></title>
<title locale="zh_CN"><![CDATA[Kai Icons]]></title>
</titles>
<descriptions>
<description locale="en_US"><![CDATA[Icons generated from wallpaper colors]]></description>
<description locale="zh_CN"><![CDATA[Icons generated from wallpaper colors]]></description>
</descriptions>
<miuiAdapterVersion>3.2</miuiAdapterVersion>
</theme>
"""
        return ByteArrayOutputStream().also { bos ->
            ZipOutputStream(bos).use { z ->
                z.putNextEntry(ZipEntry("description.xml")); z.write(desc.toByteArray()); z.closeEntry()
                z.putNextEntry(ZipEntry("icons")); z.write(icons); z.closeEntry()
                z.putNextEntry(ZipEntry("preview/preview_icons_0.jpg")); z.write(prevJpg); z.closeEntry()
            }
        }.toByteArray()
    }
}
